const express = require('express');
const db = require('./db');

const app = express();
const PORT = 3000;

app.use(express.json());

// Ruta para obtener todos los sneakers
app.get('/api/sneakers', (req, res) => {
  const sql = 'SELECT * FROM sneakers';
  db.query(sql, (err, result) => {
    if (err) {
      res.status(500).json({ message: err.message });
    } else {
      res.json(result);
    }
  });
});

// Ruta para crear un nuevo sneaker
app.post('/api/sneakers', (req, res) => {
  const { name, size, brand, description, price, stock, image } = req.body;

  const sql = 'INSERT INTO sneakers (name, size, brand, description, price, stock, image) VALUES (?, ?, ?, ?, ?)';
  db.query(sql, [name, size, brand, description, price, stock, image], (err, result) => {
    if (err) {
      return res.status(400).json({ message: err.message });
    } else {
      return res.status(201).json({ message: 'Sneaker creado exitosamente' });
    }
  });
});

// Ruta para actualizar un sneaker por su ID
app.put('/api/sneakers/:id', (req, res) => {
  const sneakerId = req.params.id;
  const { name, size, brand, description, price, stock, image } = req.body;

  const sql = 'UPDATE sneakers SET name = ?, size = ?, brand = ?, image = ? WHERE id = ?';
  db.query(sql, [name, size, brand, description, price, stock, image, sneakerId], (err, result) => {
    if (err) {
      return res.status(400).json({ message: err.message });
    } else {
      if (result.affectedRows === 0) {
        return res.status(404).json({ message: 'No se encontró el sneaker con el ID proporcionado' });
      } else {
        return res.status(200).json({ message: 'Sneaker actualizado exitosamente' });
      }
    }
  });
});

// Ruta para eliminar un sneaker por su ID
app.delete('/api/sneakers/:id', (req, res) => {
  const sneakerId = req.params.id;

  const sql = 'DELETE FROM sneakers WHERE id = ?';
  db.query(sql, [sneakerId], (err, result) => {
    if (err) {
      return res.status(400).json({ message: err.message });
    } else {
      if (result.affectedRows === 0) {
        return res.status(404).json({ message: 'No se encontró el sneaker con el ID proporcionado' });
      } else {
        return res.status(200).json({ message: 'Sneaker eliminado exitosamente' });
      }
    }
  });
});



// Iniciar el servidor
app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});
